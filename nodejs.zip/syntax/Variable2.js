var letter = ' is the standard markup language for creating web pages and web applications.Web browsers receive HTML documents from a web server or from local storage and render them into multimedia web pages. HTML describes the structure of a web page semantically and originally included cues for the appearance of the document.';


console.log(letter);

//중복을 제거해야 좋은 프로그램이다.


var name = 'egoing';
var letter1 = 'Dear'+name+'djfkldjlfkdlj'+name+'llslslslllslslls'+'hahahahahahahahah';
console.log(letter1)
