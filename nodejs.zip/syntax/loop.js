console.log('A');
console.log('B');

var i=0;
while(i<10) {

  console.log('c1');
  console.log('c2');
  i=i+1;

}

console.log('D');
