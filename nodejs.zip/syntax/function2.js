console.log(Math.round(1.6)); //반올림
console.log(Math.round(2.1));


function sum(a,b) { // parameter
  return (a+b);
}

var c = sum(2,4); //2,4 -> argument
console.log(c);
