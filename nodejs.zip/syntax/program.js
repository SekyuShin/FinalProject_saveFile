//프로그램이란, 시간의 순서에 따라 실행
console.log('A');
console.log('B');

console.log('c1');
console.log('c2');

//둘중 하나를 실행시키면 프로그램 두개를 만들어야한다.
// 그래서 나온게, flow control statement
