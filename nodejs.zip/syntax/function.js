var a = 'A';
var i = 0;

console.log('A');
console.log('d');
console.log(3);
f123();
console.log(1);
console.log(2);
console.log(3);
f123();
console.log(1);
console.log(2);
console.log(3);
console.log(1);
console.log(2);
console.log(3);
f123();

function f123() {
  console.log(1);
  console.log(2);
  console.log(3);

}
