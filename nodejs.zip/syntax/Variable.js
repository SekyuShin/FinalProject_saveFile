a = 1;
console.log(a);

var b = 2; // var 붙이자.
console.log(b);
