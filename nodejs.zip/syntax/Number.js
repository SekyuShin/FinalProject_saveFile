console.log(1+2*3);
