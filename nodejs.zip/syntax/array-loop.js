var number = [1,300,12,34,5];
var i =0;
var sum =0;
while(i<number.length) {
  sum+=number[i];
  console.log(number[i]);
  i=i+1;
}
console.log("sum = "+sum);
