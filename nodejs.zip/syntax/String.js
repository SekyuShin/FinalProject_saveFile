//문자열은 따음표로 묶는다.
console.log(1+1); //2
console.log("1"+"1"); //11
console.log(' is the standard markup language for creating web pages and web applications.Web browsers receive HTML documents from a web server or from local storage and render them into multimedia web pages. HTML describes the structure of a web page semantically and originally included cues for the appearance of the document.'.length);
