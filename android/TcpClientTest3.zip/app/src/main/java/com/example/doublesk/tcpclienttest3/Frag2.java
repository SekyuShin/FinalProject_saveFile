package com.example.doublesk.tcpclienttest3;

import android.annotation.SuppressLint;
import android.app.Fragment;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

public class Frag2 extends Fragment {

    Button updateBtn,deleteBtn;
    TextView UDtext;
    TcpThread tcp;
    Handler msgHandler2;
    final String updateMsg = "Android_update_go to movie with friends_201905232210_201905232320_back to the home_201905231110_201905231220";
    final String deleteMsg = "Android_delete_go to movie with friends_201905232210_201905232320";

    @SuppressLint("HandlerLeak")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_frag2, container, false);
        updateBtn = (Button) v.findViewById(R.id.updateBtn);
        deleteBtn = (Button) v.findViewById(R.id.deleteBtn);
        UDtext = (TextView) v.findViewById(R.id.UDtext);

        msgHandler2 = new Handler() {
            public void handleMessage(Message msg) {
                //super.handleMessage(msg);
                if (msg.what == 2222) {
                    Log.d("Tag", "msg : " + msg.obj.toString());
                    try {
                        UDtext.setText(msg.obj.toString() + '\n');
                    }catch(Exception e) {
                        e.printStackTrace();
                        Log.d("Test","err : "+e);
                    }
                    //tcp.ThreadCheck();
                    try {
                        tcp.socket.close();
                        tcp.ThreadCheck();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        };

        updateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tcp = new TcpThread("192.168.0.5", 3000, msgHandler2);
                tcp.clientStart(updateMsg);
            }
        });
        deleteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tcp = new TcpThread("192.168.0.5", 3000, msgHandler2);
                tcp.clientStart(deleteMsg);
            }
        });
        return v;

    }
}