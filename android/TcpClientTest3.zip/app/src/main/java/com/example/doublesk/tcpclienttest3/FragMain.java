package com.example.doublesk.tcpclienttest3;


import android.app.Fragment;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListView;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragMain extends Fragment {

    TcpThread tcp;
    Handler msgHandler;
    Button listBtn;
    MainActivity activity;
    ListView listView;
    ListViewAdapter adapter;
    String msg = "Android_list_20190501_20190531";

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_frag_main, container, false);
        listView = (ListView)v.findViewById(R.id.listView);
        listBtn = (Button)v.findViewById(R.id.listBtn);

        activity = (MainActivity)getActivity();
        Log.d("Test","mList : "+ObjectUtils.isEmpty(activity.mList.getGlobalList()));
        if(ObjectUtils.isEmpty(activity.mList.getGlobalList())) {
            tcp = new TcpThread("192.168.0.5",3000, msgHandler);
            tcp.clientStart(msg);
        } else {
            adapter = new ListViewAdapter(activity.mList.getGlobalList()) ;
            listView.setAdapter(adapter);
        }

        listBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tcp = new TcpThread("192.168.0.5",3000, msgHandler);
                tcp.clientStart(msg);
            }
        });
        // Inflate the layout for this fragment
        return v;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d("Test","onCreate");



        msgHandler = new Handler() {
            public void handleMessage(Message msg) {
                if(msg.what == 2222) {
                    Log.d("Tag","msg : "+msg.obj.toString());
                    activity.mList.clear();
                    activity.mList.setGlobalList(msg.obj.toString());
                    adapter = new ListViewAdapter(activity.mList.getGlobalList()) ;
                    listView.setAdapter(adapter);
                    try {
                        tcp.socket.close();
                        tcp.ThreadCheck();
                    }catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        };
    }
}

