package com.example.doublesk.tcpclienttest3;

import android.annotation.SuppressLint;
import android.app.Fragment;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;


public class Frag1 extends Fragment {


    Button addBtn;
    TextView text;
    TcpThread tcp;
    Handler msgHandler;
    String msg="Android_insert_go to movie with friends_201905232210_201905232320";
    @SuppressLint("HandlerLeak")

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_frag1, container, false);
        addBtn = (Button)v.findViewById(R.id.addBtn);
        text = (TextView)v.findViewById(R.id.text);

        msgHandler = new Handler() {

            public void handleMessage(Message msg) {
                if(msg.what == 2222) {
                    Log.d("Tag","msg : "+msg.obj.toString());
                    text.setText(msg.obj.toString()+'\n');
                    //tcp.ThreadCheck();
                    try {
                        tcp.socket.close();
                        tcp.ThreadCheck();
                    }catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        };

        addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tcp = new TcpThread("192.168.0.5",3000, msgHandler);
                tcp.clientStart(msg);
            }
        });
        // Inflate the layout for this fragment

        return v;
    }


}
