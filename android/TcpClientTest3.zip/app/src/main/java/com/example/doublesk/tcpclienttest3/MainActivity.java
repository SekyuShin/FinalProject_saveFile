package com.example.doublesk.tcpclienttest3;


import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    Button btn1,btn2,btn0;
    FragmentManager fm;
    FragmentTransaction tran;
    Frag1 frag1;
    Frag2 frag2;
    FragMain fragMain;
    int a = 100;
    LIST mList ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mList = (LIST)getApplication();
        btn0 = (Button)findViewById(R.id.btn0);
        btn1 = (Button)findViewById(R.id.btn1);
        btn2 = (Button)findViewById(R.id.btn2);

        btn0.setOnClickListener(this);
        btn1.setOnClickListener(this);
        btn2.setOnClickListener(this);

        frag1 = new Frag1();
        frag2 = new Frag2();
        fragMain = new FragMain();

        setFrag(0);
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()) {
            case R.id.btn0:
                setFrag(0);
                break;
            case R.id.btn1:
                Log.d("Test","btn1 click");
                setFrag(1);
                break;
            case R.id.btn2:
                Log.d("Test","btn2 click");
                setFrag(2);
        }
    }
    public void setFrag(int n) {
        fm = getFragmentManager();
        tran = fm.beginTransaction();
        Log.d("Test","n = "+n);
        switch(n) {
            case 0:
                Log.d("Test","frag0 exe");
                tran.replace(R.id.main_fram,fragMain);
                tran.commit();
                break;
            case 1:
                Log.d("Test","frag1 exe");
                tran.replace(R.id.main_fram,frag1);
                tran.commit();
                break;
            case 2:
                Log.d("Test","frag2 exe");
                tran.replace(R.id.main_fram,frag2);
                tran.commit();
                break;

        }
    }
}
