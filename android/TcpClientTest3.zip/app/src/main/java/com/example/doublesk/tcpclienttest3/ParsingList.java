package com.example.doublesk.tcpclienttest3;

import android.util.Log;

import java.util.ArrayList;
import java.util.HashMap;

public class ParsingList {
    String START = "START";
    String END = "END";
    String TEXT = "TEXT";

    ArrayList<HashMap<String, String>> mArrayList = new ArrayList<>();


    int sizeList(String str)  {
        int count = 0;
        char c = '_';
        for(int i=0;i<str.length();i++)  {
            if(str.charAt(i) == c)
                count++;
        }
        return count;
    }
    public void clear() {
        mArrayList.clear();
    }
    public void inputList(String data) {
        data = data.substring(1, data.length());
        for (int i = 0; i < sizeList(data); i+=3) {
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put(START, data.split("_")[i]);
            hashMap.put(END,data.split("_")[i+1]);
            hashMap.put(TEXT,data.split("_")[i+2]);
            mArrayList.add(hashMap);
        }
    }
    public void showList() {
        for (int i = 0; i < mArrayList.size(); i++) {
            HashMap<String, String> hashMap = mArrayList.get(i);
            Log.d("Test", hashMap.get(START) + " " + hashMap.get(END) + " " + hashMap.get(TEXT));
        }
    }
    public ArrayList<HashMap<String, String>> getList() {
        return mArrayList;
    }
}
