package com.example.doublesk.tcpclienttest3;

import android.app.Application;

import java.util.ArrayList;
import java.util.HashMap;

public class LIST extends Application  {
    private ParsingList list;
    public void onCreate() {
        super.onCreate();
        list = new ParsingList();
    }

    public ArrayList<HashMap<String, String>> getGlobalList() {
        return list.getList();
    }
    public void setGlobalList(String str) {
        this.list.inputList(str);
    }
    public void clear() {
        list.clear();
    }

}
